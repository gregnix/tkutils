# sqlite-editor

A SQLite database editor, browser and inspector built on the **tkutils** widget
family (`tkutoolbar`, `tkustatus`, `tkudialog`) plus `ttk` (notebook, treeview).

It is the first member of a planned family of database editors (sqlite /
postgresql / oracle) that share one UI behind a thin backend boundary: every
SQLite-specific query lives in `::sqledit::be::*`, so a PostgreSQL (tdbc) or
Oracle (oratcl) backend can later be dropped in behind the same procs.

## Features
- **Editor** -- free-form SQL with **F5** / *Execute*; results in a grid.
- **Browser** -- object tree of tables / views / indexes / triggers /
  sequences; double-click a table or view to browse its rows.
- **Information** -- per-object details (columns, PK/NOT NULL, CREATE text) and
  a database summary (version, encoding, size, object counts).
- **History** -- every executed statement with time and status; double-click to
  reload it into the editor.
- **Export result** as CSV (`tclutils::tucsv`) or text (`tclutils::tutable`).
- **Export schema** -- the full set of CREATE statements as a runnable `.sql`.
- **Open URLs** -- for columns whose name contains `url` (e.g. `name_url`,
  `club_url`) the form shows an *"Im Browser öffnen"* button per such column, and
  the datasheet offers a right-click *"Im Browser öffnen"* entry; both open the
  cell's URL in the system browser (`xdg-open` / `open` / `start`). The button /
  menu entry is enabled only when the current cell holds an `http(s)://` value.

## Requirements
- Tcl/Tk 8.6+ or 9.x
- the external **sqlite3** package (tclsqlite) -- the only hard dependency
- **tkutils** and **tclutils** as sibling directories (or via the
  `TKUTILS_TM` / `TCLUTILS_TM` environment variables)

## Run
```
wish sqlite-editor.tcl ?database.db?
```

## Headless / testing
The whole data and introspection layer is dialog-free
(`::sqledit::_*`, backend `::sqledit::be::*`): `_open`, `_run` (returns
`{columns rows changes}`), `_objects type`, `_columns`, `_schemaOf`, `_info`,
`_schemaDump`, `_history*`, `_export{Csv,Text,Schema}`.

The three `tcltest` files live in the repository root and are run individually
(there is no aggregator script). `sqlite_editor.test` is Tk-free and runs under
`tclsh`; the form and datasheet suites drive Tk widgets, so run them under a
display, e.g. `xvfb-run`:

```sh
tclsh sqlite_editor.test               # data + introspection layer (no Tk)
xvfb-run -a wish sqledit_form.test     # form widget   (needs Tk)
xvfb-run -a wish sqledit_sheet.test    # datasheet     (needs Tk)
```

If `tkutils` / `tclutils` are not siblings, prefix the commands with
`TKUTILS_TM=/path/tkutils/lib/tm TCLUTILS_TM=/path/tclutils/lib/tm`.

Generate a sample database with `tclsh make-demo.tcl`.
