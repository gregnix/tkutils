#!/usr/bin/env wish
# sqlite_editor.tcl -- a SQLite database editor, browser and inspector.
#
# Part of a planned family of database editors (sqlite / postgresql / oracle)
# that share one UI and a thin backend boundary. Everything SQLite-specific
# lives in the "backend" section (::sqledit::be::*); the rest of the data layer
# and the GUI are backend-agnostic, so a PostgreSQL (tdbc) or Oracle (oratcl)
# backend can later be dropped in behind the same procs.
#
# Features: SQL editor + result grid, an object browser (tables / views /
# indexes / triggers / sequences), per-object and database information, a query
# history, CSV/text export of the current result, and full schema export.
#
# The data layer is dialog-free (::sqledit::_* and ::sqledit::be::*), so the
# tool can be driven headlessly; see tests/sqlite_editor.test. The GUI is built
# only when the file is run as the main script.

package require Tcl 8.6-


namespace eval ::sqledit {
    variable S
    array set S {
        db "" file "" w "" status "" browser "" sql "" info "" hist "" nb ""
        limit 500 rescols "" resrows ""
    }
    variable HISTORY {}
}

# =============================================================================
# Data layer (backend-agnostic, dialog-free -- unit-testable)
# =============================================================================

proc ::sqledit::_isOpen {} { variable S; expr {$S(db) ne ""} }

# Quote an SQL identifier (double any embedded double-quotes).
proc ::sqledit::_qid {s} { return [string map {\" \"\"} $s] }

# A value worth offering an "open" action for.
proc ::sqledit::_isUrl {s} { return [regexp {^\s*https?://} $s] }

# Open a URL in the system browser (Linux/macOS/Windows). Returns 1 on success.
proc ::sqledit::_openUrl {url} {
    set url [string trim $url]
    if {![_isUrl $url]} { _setText "Keine gültige URL."; return 0 }
    foreach exe {xdg-open open} {
        set p [auto_execok $exe]
        if {[llength $p] && ![catch {exec {*}$p $url &}]} { return 1 }
    }
    set cmd [auto_execok cmd.exe]
    if {[llength $cmd] && ![catch {exec {*}$cmd /c start {} $url &}]} { return 1 }
    set st [auto_execok start]
    if {[llength $st] && ![catch {exec {*}$st {} $url &}]} { return 1 }
    _setText "Konnte den Browser nicht öffnen."
    return 0
}

proc ::sqledit::_open {target} {
    variable S
    _close
    set S(db) [::sqledit::be::open $target]
    set S(target) $target
    set S(file) [::sqledit::be::label $target]
    return $target
}
proc ::sqledit::_close {} {
    variable S
    if {[_isOpen]} { ::sqledit::be::close $S(db) }
    set S(db) ""; set S(file) ""
}
proc ::sqledit::_run {sql} {
    variable S
    if {![_isOpen]} { return -code error -errorcode {SQLEDIT NODB} "no database open" }
    return [::sqledit::be::run $S(db) $sql]
}
proc ::sqledit::_objects {type} {
    variable S
    if {![_isOpen]} { return {} }
    return [::sqledit::be::objects $S(db) $type]
}
proc ::sqledit::_tables {} { return [_objects table] }
proc ::sqledit::_schemaOf {name} {
    variable S
    if {![_isOpen]} { return "" }
    return [::sqledit::be::schemaOf $S(db) $name]
}
proc ::sqledit::_columns {name} {
    variable S
    if {![_isOpen]} { return {} }
    return [::sqledit::be::columns $S(db) $name]
}
proc ::sqledit::_info {} {
    variable S
    if {![_isOpen]} { return {} }
    return [::sqledit::be::summary $S(db)]
}
proc ::sqledit::_schemaDump {} {
    variable S
    if {![_isOpen]} { return "" }
    return [::sqledit::be::schemaDump $S(db)]
}

# --- history -----------------------------------------------------------------
proc ::sqledit::_historyAdd {sql status} {
    variable HISTORY
    lappend HISTORY [dict create time [clock format [clock seconds] -format %H:%M:%S] \
        status $status sql $sql]
    return [llength $HISTORY]
}
proc ::sqledit::_history {} { variable HISTORY; return $HISTORY }

# --- export (reuse tclutils engines, with plain fallbacks) -------------------
proc ::sqledit::_exportCsv {path columns rows} {
    set all [linsert $rows 0 $columns]
    if {![catch {package require tclutils::tucsv}]} {
        ::tclutils::tucsv::writeFile $path $all
    } else {
        set ch [::open $path w]
        foreach r $all {
            set f {}
            foreach v $r {
                if {[string match {*[",
]*} $v]} { set v \"[string map {\" \"\"} $v]\" }
                lappend f $v
            }
            puts $ch [join $f ,]
        }
        ::close $ch
    }
    return $path
}
proc ::sqledit::_exportText {path columns rows} {
    if {![catch {package require tclutils::tutable}]} {
        set txt [::tclutils::tutable::render $columns $rows]
    } else {
        set txt [join $columns \t]\n
        foreach r $rows { append txt [join $r \t] \n }
    }
    set ch [::open $path w]; puts $ch $txt; ::close $ch
    return $path
}
proc ::sqledit::_exportSchema {path} {
    set ch [::open $path w]; puts $ch [_schemaDump]; ::close $ch
    return $path
}

# =============================================================================
# GUI
# =============================================================================

proc ::sqledit::requireDeps {} {
    if {[catch {::sqledit::be::requireDeps} err]} {
        if {[namespace exists ::tkutils::tkudialog]} {
            ::tkutils::tkudialog::showError $err
        } else { puts stderr "sqledit: $err" }
        exit 1
    }
}

# Call an optional backend label proc (::sqledit::be::<name>), else $default.
proc ::sqledit::_beLabel {name default} {
    if {[llength [info procs ::sqledit::be::$name]]} {
        return [::sqledit::be::$name]
    }
    return $default
}

proc ::sqledit::buildApp {toplevel} {
    variable S
    package require Tk 8.6-
    package require tkutils::tkutoolbar
    package require tkutils::tkustatus
    package require tkutils::tkudialog

    set P $toplevel
    if {$P eq "."} { set P "" }

    set tb [::tkutils::tkutoolbar::widget $P.tb]
    pack $tb -side top -fill x
    ::tkutils::tkutoolbar::addButton $tb open [_beLabel connectLabel "Connect…"] ::sqledit::cmdOpen
    if {[llength [info procs ::sqledit::be::connectNew]]} {
        ::tkutils::tkutoolbar::addButton $tb new [_beLabel connectNewLabel "New"] ::sqledit::cmdNew
    }
    ::tkutils::tkutoolbar::addSeparator $tb
    ::tkutils::tkutoolbar::addButton $tb exec "Execute (F5)" ::sqledit::cmdExecute
    ::tkutils::tkutoolbar::addButton $tb refr "Refresh"      ::sqledit::cmdRefresh

    set pw [ttk::panedwindow $P.pw -orient horizontal]
    pack $pw -side top -fill both -expand 1

    # --- left: object browser ---
    set lf [ttk::labelframe $pw.db -text "Database"]
    set br [ttk::treeview $lf.tv -show tree -selectmode browse \
        -yscrollcommand [list $lf.sb set]]
    ttk::scrollbar $lf.sb -orient vertical -command [list $br yview]
    pack $lf.sb -side right -fill y
    pack $br -side left -fill both -expand 1
    bind $br <Double-1> ::sqledit::cmdOpenObject
    bind $br <<TreeviewSelect>> ::sqledit::_onSelect
    set S(browser) $br

    # --- right: SQL editor over a notebook (Result / Info / History) ---
    set right [ttk::panedwindow $pw.work -orient vertical]

    set qf [ttk::labelframe $right.query -text "SQL"]
    set txt [text $qf.t -height 6 -wrap none -undo 1 \
        -yscrollcommand [list $qf.sb set]]
    ttk::scrollbar $qf.sb -orient vertical -command [list $txt yview]
    set bar [ttk::frame $qf.bar]
    ttk::button $bar.run -text "Execute" -command ::sqledit::cmdExecute
    ttk::button $bar.clr -text "Clear"   -command ::sqledit::clearSql
    pack $bar.run $bar.clr -side left -padx 2
    pack $bar -side bottom -fill x -pady 2
    pack $qf.sb -side right -fill y
    pack $txt -side left -fill both -expand 1
    set S(sql) $txt

    set nb [ttk::notebook $right.nb]
    set S(nb) $nb

    # Result tab
    set rf [ttk::frame $nb.result]
    set ebar [ttk::frame $rf.bar]
    ttk::button $ebar.csv -text "Export CSV"  -command {::sqledit::cmdExportResult csv}
    ttk::button $ebar.txt -text "Export Text" -command {::sqledit::cmdExportResult text}
    pack $ebar.csv $ebar.txt -side left -padx 2
    pack $ebar -side bottom -fill x -pady 2
    set gf [ttk::frame $rf.grid]
    pack $gf -side top -fill both -expand 1
    set tv [ttk::treeview $gf.tv -show headings \
        -yscrollcommand [list $gf.vsb set] -xscrollcommand [list $gf.hsb set]]
    ttk::scrollbar $gf.vsb -orient vertical   -command [list $tv yview]
    ttk::scrollbar $gf.hsb -orient horizontal -command [list $tv xview]
    grid $tv $gf.vsb -sticky nsew
    grid $gf.hsb     -sticky ew
    grid rowconfigure $gf 0 -weight 1
    grid columnconfigure $gf 0 -weight 1
    set S(w) $tv
    $nb add $rf -text "Result"

    # Info tab
    set inf [ttk::frame $nb.info]
    set itxt [text $inf.t -wrap word -state disabled \
        -yscrollcommand [list $inf.sb set]]
    ttk::scrollbar $inf.sb -orient vertical -command [list $itxt yview]
    pack $inf.sb -side right -fill y
    pack $itxt -side left -fill both -expand 1
    set S(info) $itxt
    $nb add $inf -text "Info"

    # History tab
    set hf [ttk::frame $nb.hist]
    set hv [ttk::treeview $hf.tv -show headings -columns {time status sql} \
        -yscrollcommand [list $hf.sb set]]
    $hv heading time -text "Time";    $hv column time -width 70 -stretch 0
    $hv heading status -text "Status"; $hv column status -width 70 -stretch 0
    $hv heading sql -text "SQL";      $hv column sql -width 400
    ttk::scrollbar $hf.sb -orient vertical -command [list $hv yview]
    pack $hf.sb -side right -fill y
    pack $hv -side left -fill both -expand 1
    bind $hv <Double-1> ::sqledit::cmdLoadHistory
    set S(hist) $hv
    $nb add $hf -text "History"

    # optional Form view (sqledit-form.tcl); present only if sourced
    if {[llength [info procs ::sqledit::_formBuild]]} { ::sqledit::_formBuild $nb }
    # optional editable datasheet (sqledit-sheet.tcl)
    if {[llength [info procs ::sqledit::_sheetBuild]]} { ::sqledit::_sheetBuild $nb }

    $right add $qf -weight 1
    $right add $nb -weight 3
    $pw add $lf    -weight 1
    $pw add $right -weight 4

    set st [::tkutils::tkustatus::widget $P.status]
    pack $st -side bottom -fill x
    ::tkutils::tkustatus::addField $st rows -width 14
    set S(status) $st

    _menu $toplevel
    bind $toplevel <F5> ::sqledit::cmdExecute
    bind $toplevel <Control-o> ::sqledit::cmdOpen
    bind $toplevel <Control-n> ::sqledit::cmdNew

    _setText "No database open."
    _retitle
    return $tv
}

proc ::sqledit::_menu {toplevel} {
    set m [menu $toplevel.menu]; $toplevel configure -menu $m
    set file [menu $m.file -tearoff 0]; $m add cascade -label "File" -menu $file
    $file add command -label "Open..." -accelerator "Ctrl+O" -command ::sqledit::cmdOpen
    $file add command -label "New..."  -accelerator "Ctrl+N" -command ::sqledit::cmdNew
    $file add command -label "Close"   -command ::sqledit::cmdClose
    $file add separator
    $file add command -label "Export Schema..." -command ::sqledit::cmdExportSchema
    $file add separator
    $file add command -label "Quit" -command {destroy .}
    set q [menu $m.query -tearoff 0]; $m add cascade -label "Query" -menu $q
    $q add command -label "Execute" -accelerator "F5" -command ::sqledit::cmdExecute
    $q add command -label "Clear"   -command ::sqledit::clearSql
    $q add separator
    $q add command -label "Export Result as CSV..."  -command {::sqledit::cmdExportResult csv}
    $q add command -label "Export Result as Text..." -command {::sqledit::cmdExportResult text}
    set v [menu $m.view -tearoff 0]; $m add cascade -label "View" -menu $v
    $v add command -label "Refresh" -command ::sqledit::cmdRefresh
}

# --- helpers -----------------------------------------------------------------
proc ::sqledit::_setText {msg} {
    variable S
    if {$S(status) ne ""} { ::tkutils::tkustatus::setText $S(status) $msg }
}
proc ::sqledit::_setRows {n} {
    variable S
    if {$S(status) ne ""} { ::tkutils::tkustatus::setField $S(status) rows "$n rows" }
}
proc ::sqledit::_retitle {} {
    variable S
    set dn   [_beLabel displayName "SQL"]
    set name [expr {$S(file) eq "" ? "(not connected)" : $S(file)}]
    catch {wm title . "$dn Editor - $name"}
}
proc ::sqledit::clearSql {} { variable S; $S(sql) delete 1.0 end }

proc ::sqledit::_infoShow {text} {
    variable S
    set w $S(info)
    $w configure -state normal
    $w delete 1.0 end
    $w insert 1.0 $text
    $w configure -state disabled
}

# --- commands: open / refresh ------------------------------------------------
proc ::sqledit::cmdOpen {} {
    variable S
    set target [::sqledit::be::connect $S(w)]
    if {$target ne ""} { _connectTo $target }
}
proc ::sqledit::cmdNew {} {
    variable S
    if {![llength [info procs ::sqledit::be::connectNew]]} return
    set target [::sqledit::be::connectNew $S(w)]
    if {$target ne ""} { _connectTo $target }
}
proc ::sqledit::_connectTo {target} {
    if {[catch {_open $target} err]} {
        ::tkutils::tkudialog::showError "Could not connect:\n$err"; return
    }
    cmdRefresh
    _showDbInfo
    _setText "Connected: [::sqledit::be::label $target]"
    _retitle
}
proc ::sqledit::cmdClose {} {
    variable S
    _close
    $S(browser) delete [$S(browser) children {}]
    _clearResult
    _infoShow ""
    _setText "No database open."; _setRows 0; _retitle
}
proc ::sqledit::cmdRefresh {} {
    variable S
    if {![_isOpen]} return
    set br $S(browser)
    $br delete [$br children {}]
    foreach {type label} [::sqledit::be::categories] {
        set objs [_objects $type]
        if {![llength $objs]} continue
        set cat [$br insert {} end -text "$label ([llength $objs])" -open 0 \
            -values [list category ""]]
        foreach o $objs {
            $br insert $cat end -text $o -values [list $type $o]
        }
    }
    if {[llength [info procs ::sqledit::_formRefresh]]} { ::sqledit::_formRefresh }
    if {[llength [info procs ::sqledit::_sheetRefresh]]} { ::sqledit::_sheetRefresh }
}

# --- commands: browser interaction ------------------------------------------
proc ::sqledit::_selValues {} {
    variable S
    set sel [$S(browser) selection]
    if {$sel eq ""} { return {} }
    return [$S(browser) item [lindex $sel 0] -values]
}
proc ::sqledit::_onSelect {} {
    lassign [_selValues] type name
    if {$type eq "" || $type eq "category"} { _showDbInfo; return }
    _showObjectInfo $type $name
}
proc ::sqledit::cmdOpenObject {} {
    variable S
    lassign [_selValues] type name
    if {$type in {table view}} {
        $S(sql) delete 1.0 end
        $S(sql) insert 1.0 [::sqledit::be::previewSql $name $S(limit)]
        cmdExecute
    }
}
proc ::sqledit::_showDbInfo {} {
    variable S
    if {![_isOpen]} { _infoShow ""; return }
    _infoShow [::sqledit::be::summaryText $S(db)]
}
proc ::sqledit::_showObjectInfo {type name} {
    set t "[string toupper $type 0 0]: $name\n\n"
    if {$type in {table view}} {
        append t "Columns:\n"
        foreach c [_columns $name] {
            append t [format "  %-22s %-12s%s%s\n" \
                [dict get $c name] [dict get $c type] \
                [expr {[dict get $c notnull] ? "NOT NULL " : ""}] \
                [expr {[dict get $c pk] ? "PK" : ""}]]
        }
        append t "\n"
    }
    set sql [_schemaOf $name]
    if {$sql ne ""} { append t "Schema:\n$sql\n" }
    _infoShow $t
}

# --- commands: execute -------------------------------------------------------
proc ::sqledit::cmdExecute {} {
    variable S
    if {![_isOpen]} { ::tkutils::tkudialog::showWarning "Open a database first."; return }
    set sql [string trim [$S(sql) get 1.0 end]]
    if {$sql eq ""} return
    if {[catch {_run $sql} res]} {
        _histPush $sql "error"
        ::tkutils::tkudialog::showError "SQL error:\n$res"
        _setText "Error"; return
    }
    set cols [dict get $res columns]
    if {[llength $cols]} {
        _showResult $cols [dict get $res rows]
        $S(nb) select 0
        _histPush $sql "[llength [dict get $res rows]] rows"
        _setText "OK"
    } else {
        _clearResult
        set n [dict get $res changes]
        _histPush $sql "$n changed"
        _setText "OK - $n row(s) affected"
        cmdRefresh
    }
}
proc ::sqledit::_histPush {sql status} {
    variable S
    _historyAdd $sql $status
    set one [string map {\n " "} [string trim $sql]]
    $S(hist) insert {} 0 -values [list [clock format [clock seconds] -format %H:%M:%S] \
        $status $one]
}
proc ::sqledit::cmdLoadHistory {} {
    variable S
    set sel [$S(hist) selection]
    if {$sel eq ""} return
    set sql [lindex [$S(hist) item [lindex $sel 0] -values] 2]
    $S(sql) delete 1.0 end
    $S(sql) insert 1.0 $sql
}

# --- result grid + export ----------------------------------------------------
proc ::sqledit::_clearResult {} {
    variable S
    set tv $S(w)
    $tv delete [$tv children {}]
    $tv configure -columns {}
    set S(rescols) ""; set S(resrows) ""
    _setRows 0
}
proc ::sqledit::_showResult {cols rows} {
    variable S
    set tv $S(w)
    $tv delete [$tv children {}]
    set ids {}; set i 0
    foreach c $cols { lappend ids c[incr i] }
    $tv configure -columns $ids
    set i 0
    foreach c $cols {
        set id [lindex $ids $i]
        $tv heading $id -text $c
        $tv column $id -width 120 -stretch 1 -anchor w
        incr i
    }
    foreach r $rows { $tv insert {} end -values $r }
    set S(rescols) $cols; set S(resrows) $rows
    _setRows [llength $rows]
}
proc ::sqledit::cmdExportResult {fmt} {
    variable S
    if {![llength $S(rescols)]} {
        ::tkutils::tkudialog::showWarning "No result to export. Run a SELECT first."
        return
    }
    if {$fmt eq "csv"} {
        set f [tk_getSaveFile -title "Export result as CSV" -defaultextension .csv \
            -filetypes {{CSV .csv} {All *}}]
    } else {
        set f [tk_getSaveFile -title "Export result as text" -defaultextension .txt \
            -filetypes {{Text .txt} {All *}}]
    }
    if {$f eq ""} return
    if {[catch {
        if {$fmt eq "csv"} {
            _exportCsv $f $S(rescols) $S(resrows)
        } else {
            _exportText $f $S(rescols) $S(resrows)
        }
    } err]} {
        ::tkutils::tkudialog::showError "Export failed:\n$err"; return
    }
    _setText "Exported to [file tail $f]"
}
proc ::sqledit::cmdExportSchema {} {
    if {![_isOpen]} { ::tkutils::tkudialog::showWarning "Open a database first."; return }
    set f [tk_getSaveFile -title "Export schema" -defaultextension .sql \
        -filetypes {{SQL .sql} {All *}}]
    if {$f eq ""} return
    if {[catch {_exportSchema $f} err]} {
        ::tkutils::tkudialog::showError "Export failed:\n$err"; return
    }
    _setText "Schema exported to [file tail $f]"
}
