#!/usr/bin/env wish
# sqlite-editor.tcl -- launcher for the SQLite variant of the editor family.
#
# Thin entry point: locate tclutils/tkutils, load the shared core and the
# SQLite backend, then build the GUI. The PostgreSQL and Oracle editors are
# identical launchers that source be-postgres.tcl / be-oracle.tcl instead.
#
#   wish sqlite-editor.tcl ?database-file?

package require Tcl 8.6-

# --- locate tkutils / tclutils (tcl::tm) for in-place use ---------------------
apply {{} {
    set here [file dirname [file normalize [info script]]]
    foreach lib {TCLUTILS TKUTILS} {
        if {[info exists ::env(${lib}_TM)]} { tcl::tm::path add $::env(${lib}_TM) }
    }
    foreach base [list $here [file dirname $here]] {
        foreach lib {tclutils tkutils} {
            set tm [file join $base $lib lib tm]
            if {[file isdirectory $tm]} { tcl::tm::path add $tm; continue }
            foreach d [lsort -decreasing -dictionary \
                    [glob -nocomplain -directory $base -type d ${lib}-*]] {
                set tm [file join $d lib tm]
                if {[file isdirectory $tm]} { tcl::tm::path add $tm; break }
            }
        }
    }
}}

set ::sqledit_dir [file dirname [file normalize [info script]]]
source [file join $::sqledit_dir sqledit-core.tcl]
source [file join $::sqledit_dir be-sqlite.tcl]
source [file join $::sqledit_dir sqledit-form.tcl]
source [file join $::sqledit_dir sqledit-sheet.tcl]

# --- main --------------------------------------------------------------------
if {[info exists argv0] && [file normalize $argv0] eq [file normalize [info script]]} {
    ::sqledit::requireDeps
    ::sqledit::buildApp .
    wm geometry . 900x600
    if {[llength $argv]} { ::sqledit::_connectTo [lindex $argv 0] }
}
